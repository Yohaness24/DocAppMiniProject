 package com.example.finalnewdocapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

 public class MainActivity extends AppCompatActivity {

     @Override
     protected void onCreate(Bundle savedInstanceState) {
         super.onCreate(savedInstanceState);
         setContentView(R.layout.activity_main);
     }

     public void launch(View v) {
         findViewById(R.id.textView1);
         Intent intent = new Intent(MainActivity.this, SecondActivity.class);
         startActivity(intent);
         setContentView(R.layout.activity_second);

         EditText nameEdit = (EditText) findViewById(R.id.name);
         EditText ageEdit = (EditText) findViewById(R.id.age);
         RadioButton maleRButton = (RadioButton) findViewById(R.id.maleRButton);
         RadioButton femaleRButton = (RadioButton) findViewById(R.id.femaleRButton);
         String name1;
         String age1;
         String gender1;

         TextView output = findViewById(R.id.output);
         Intent OpenList = getIntent();
         name1 = OpenList.getStringExtra("name");
         age1 = OpenList.getStringExtra("age");
         gender1 = OpenList.getStringExtra("gender");
         Toast.makeText(getBaseContext(), name1 + "/" + age1 + "/" + gender1,Toast.LENGTH_LONG).show();
     }

 }
